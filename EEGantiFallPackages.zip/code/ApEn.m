% 近似熵算法

x = csvread('D:\yjs\Scientific data\数据\03CSV\sub-01\test-01\fall\fall01.csv');
a = zeros(1,16);
    for j = 1:16;
        a(j) = ApproximateEntropy(x(:,j),2,0.2*std(x(:,j)));
    end
    xlswrite('D:\yjs\Scientific data\数据\04熵\sub-01\test-01\ApEn_fall01.xlsx',a,'Sheet1','A');
    
function ApEn = ApproximateEntropy(data, dim, r)

data = data(:);
N = length(data);
result = zeros(1,2);

for j = 1:2
    m = dim+j-1;
    C   = zeros(1,N-m+1);
    dataMat = zeros(m,N-m+1);
    for i = 1:m
        dataMat(i,:) = data(i:N-m+i);
    end
    
    for i = 1:N-m+1
        tempMat = abs(dataMat - repmat(dataMat(:,i),1,N-m+1));
        boolMat = any((tempMat > r),1);
        C(i) = sum(~boolMat)/(N-m+1);
    end
    
    phi(j) = sum(log(C))/(N-m+1);
end
ApEn = phi(1)-phi(2);
end




