% 排列熵算法

x = csvread('D:\yjs\Scientific data\数据\03EXCEL\sub-01\test-05\fall01.csv');
a = zeros(1,16);
    for j = 1:16;
        a(j) = kPermutationEntropy(x(:,j),6,1);
    end
    xlswrite('D:\yjs\Scientific data\数据\熵-excel\peen.xlsx',a,'Sheet1','A');

function pe = kPermutationEntropy(y,m,t)

y = y(:);
ly = length(y);
permlist = perms(1:m);
[h,~]=size(permlist);
c(1:length(permlist))=0;

 for j=1:ly-t*(m-1)
     [~,iv(j,:)]=sort(y(j:t:j+t*(m-1)));
     for jj=1:h
         if (abs(permlist(jj,:)-iv(j,:)))==0
             c(jj) = c(jj) + 1 ;
         end
     end
 end
c=c(c~=0);
p = c/sum(c);
pe = -sum(p .* log2(p));
% 归一化
pe=pe/log2(factorial(m));
end
